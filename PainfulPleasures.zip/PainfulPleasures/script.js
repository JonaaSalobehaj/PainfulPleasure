const wrapper = document.querySelector(".wrapper");
const carousel = document.querySelector(".carousel");
const firstCardWidth = carousel.querySelector(".slider-card").offsetWidth;
const arrowBtns = document.querySelectorAll(".wrapper i");
const carouselChildren = [...carousel.children];
const dotsContainer = document.querySelector(".dots-container");

let isDragging = false, isAutoPlay = true, startX, startScrollLeft, timeoutId;

// Get the number of cards that can fit in the carousel at once
let cardPerView = Math.round(carousel.offsetWidth / firstCardWidth);

// Insert copies of the last few cards to beginning of carousel for infinite scrolling
carouselChildren.slice(-cardPerView).reverse().forEach(card => {
    carousel.insertAdjacentHTML("afterbegin", card.outerHTML);
});

// Insert copies of the first few cards to end of carousel for infinite scrolling
carouselChildren.slice(0, cardPerView).forEach(card => {
    carousel.insertAdjacentHTML("beforeend", card.outerHTML);
});

// Scroll the carousel at appropriate position to hide first few duplicate cards on Firefox
carousel.classList.add("no-transition");
carousel.scrollLeft = carousel.offsetWidth;
carousel.classList.remove("no-transition");

// Add dots
const createDots = () => {
    for (let i = 0; i < 3; i++) { // Create exactly 3 dots
        const dot = document.createElement("span");
        dot.classList.add("dot");
        if (i === 0) dot.classList.add("active");
        dotsContainer.appendChild(dot);
    }
};

createDots();

const dots = document.querySelectorAll(".dot");

// Update dots based on the current scroll position
const updateDots = () => {
    const totalScrollWidth = carousel.scrollWidth - carousel.clientWidth;
    const scrollPosition = (carousel.scrollLeft / totalScrollWidth) * (dots.length - 1);
    const activeIndex = Math.round(scrollPosition);

    dots.forEach((dot, index) => {
        dot.classList.toggle("active", index === activeIndex);
    });
};

// Add event listeners for the arrow buttons to scroll the carousel left and right
arrowBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        carousel.scrollLeft += btn.id === "left" ? -firstCardWidth : firstCardWidth;
        setTimeout(updateDots, 200);
    });
});

const dragStart = (e) => {
    isDragging = true;
    carousel.classList.add("dragging");
    // Records the initial cursor and scroll position of the carousel
    startX = e.pageX;
    startScrollLeft = carousel.scrollLeft;
};

const dragging = (e) => {
    if (!isDragging) return;
    // Updates the scroll position of the carousel based on the cursor movement
    carousel.scrollLeft = startScrollLeft - (e.pageX - startX);
};

const dragStop = () => {
    isDragging = false;
    carousel.classList.remove("dragging");
    updateDots();
};

// Add event listeners for dragging functionality
carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("mousemove", dragging);
document.addEventListener("mouseup", dragStop);

// Add event listeners to the dots
dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
        carousel.scrollLeft = (carousel.scrollWidth - carousel.clientWidth) * (index / (dots.length - 1));
        updateDots();
    });
});
